import UIKit

var firstStudentSignedIn:Bool = false
//checks to see if at least one student signed in
var undoCompleted = false
//in ConfirmScreen, sets to false when new student signes in

class UndoCheckIN: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if firstStudentSignedIn == true && undoCompleted == false {
        undoImage.image = newStudentData.retrieveImageFor(id:Int(lastSignIn[0].STUDENTNUMBER), forceReload: false)
        nameLabel.text = "\(lastSignIn[0].STUDENTFIRSTNAME) \(lastSignIn[0].STUDENTLASTNAME)"
    }
    }
    
    @IBOutlet weak var undoImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBAction func confirmUndo(_ sender: Any) {
        if firstStudentSignedIn == true && undoCompleted == false { currentStudentArray.append(lastSignIn[0])

            undoCompleted = true
        }
        dismiss(animated: true, completion: nil)
    }
}
