///created by Daniel Kwon '22

import UIKit

class SignInComplete: UIViewController {

    
    @IBOutlet weak var emailButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emailButton.isHidden = true
    }
    
    //disables Swipe down to dismiss
    override func viewWillLayoutSubviews() {
        isModalInPresentation = true
    }

    @IBAction func donePressed(_ sender: Any) {
        finalAllStudentsList = []
        formArray = []
        genderArray = []
        
        finalFreshmenList = []
        finalSophomoreList = []
        finalJuniorList = []
        finalSeniorList = []
        
        currentStudentArray = newStudentData.students
        
        dismiss(animated: true, completion: nil)
    }
}
