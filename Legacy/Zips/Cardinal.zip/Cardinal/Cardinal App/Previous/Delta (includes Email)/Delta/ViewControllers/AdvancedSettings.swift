///created by Stewart Zurbuch '21

import UIKit

var jsonUserInput:String = "https:socrates.standrews-de.org/api2/csdata.cfm"

class AdvancedSettings: UIViewController {

    
    @IBOutlet weak var textField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.text = jsonUserInput
    }
    
    
    @IBAction func updateJSON(_ sender: Any) {
        jsonUserInput = textField.text!
        
        dismiss(animated: true, completion: nil)
    }
}
