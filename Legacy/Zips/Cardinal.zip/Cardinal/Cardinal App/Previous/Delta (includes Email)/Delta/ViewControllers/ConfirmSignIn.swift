///created by Daniel Kwon '22 & Stewart Zurbuch '21

import UIKit

var lastSignIn: [Student] = []
var signedInStudents: [Student] = []

class ConfirmSignIn: UIViewController {
    
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var imageController: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageController.image = newStudentData.retrieveImageFor(id:Int(currentID)!, forceReload: false)
        nameLabel.text = (newStudentData.getStudentBy(id: Int(currentID)!)?.STUDENTFIRSTNAME ?? "") + " " +  (newStudentData.getStudentBy(id: Int(currentID)!)?.STUDENTLASTNAME ?? "Student Does Not Exist!")
        for current in newStudentData.students {
            if Int(current.STUDENTNUMBER) == Int(currentID) {
                for previous in signedInStudents {
                    if previous.STUDENTNUMBER == current.STUDENTNUMBER {
                        nameLabel.text = "Already Signed In!"
                        dismiss(animated: true, completion: nil)
                    }
                }
            }
        }
    }
    
    
    @IBAction func confirmSignIn(_ sender: Any) {
        var i = 0
        for current in newStudentData.students {
            if Int(current.STUDENTNUMBER) == Int(currentID) {
                for previous in signedInStudents {
                    if previous.STUDENTNUMBER == current.STUDENTNUMBER {
                        nameLabel.text = "Already Signed In!"
                        dismiss(animated: true, completion: nil)
                        return
                    }
                }
                signedInStudents.append(current)
                lastSignIn.removeAll()
                lastSignIn.append(current)
                currentStudentArray.remove(at: i)
            }
            i += 1
        }
        
        firstStudentSignedIn = true
        undoCompleted = false
        dismiss(animated: true, completion: nil)
    }
}

