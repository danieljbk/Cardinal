///created by Dustin Fang '20 & Daniel Kwon '22

import UIKit

var finalAllStudentsList = [Student]()
var finalFreshmenList = [Student]()
var finalSophomoreList = [Student]()
var finalJuniorList = [Student]()
var finalSeniorList = [Student]()

//makes sure the TableViewController is connected to the ListViewController as the data source and the delegate(the controller)
class FinalStudentList: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for s in currentStudentArray {
            if formArray.contains(s.STUDENTFORM) {
                if genderArray.contains(s.STUDENTSEX) {
                    finalAllStudentsList.insert(s, at: 0)
                }
            }
        }
        for s in finalAllStudentsList {
            if s.STUDENTFORM == 3.0 {
                    finalFreshmenList.append(s)
            }
            if s.STUDENTFORM == 4.0 {
                    finalSophomoreList.append(s)
            }
            if s.STUDENTFORM == 5.0 {
                    finalJuniorList.append(s)
            }
            if s.STUDENTFORM == 6.0 {
                    finalSeniorList.append(s)
            }
        }
    }

    //sets number of cell
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalAllStudentsList.count
    }
    
    //adds cells to the tableView
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //identifier name must match the identifier put into the cells in the storyboard
        let cell = tableView.dequeueReusableCell(withIdentifier: "students", for: indexPath)
        
        cell.textLabel?.text = finalAllStudentsList[indexPath.item].STUDENTFIRSTNAME + " " + finalAllStudentsList[indexPath.item].STUDENTLASTNAME
        
        cell.textLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 15)
        cell.textLabel?.textColor = #colorLiteral(red: 0.6752108932, green: 0.1266627014, blue: 0.1960295141, alpha: 1)
        cell.textLabel?.textAlignment = NSTextAlignment.center

    //if you want the image of the person to show up next to their name, uncomment this line of code. However, this will lag out the entire program.
///        cell.imageView?.image = newStudentData.retrieveImageFor(id:Int(finalAllStudentsList[indexPath.item].STUDENTNUMBER), forceReload: false)

        return cell
    }
}

