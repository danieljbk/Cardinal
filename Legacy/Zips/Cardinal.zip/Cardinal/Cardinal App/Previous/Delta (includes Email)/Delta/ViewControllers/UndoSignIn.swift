///created by Daniel Kwon '22 & Stewart Zurbuch '21

import UIKit

var firstStudentSignedIn:Bool = false
//checks to see if at least one student signed in
var undoCompleted = false
//in ConfirmScreen, sets to false when new student signes in

class UndoSignIn: UIViewController {
    
    
    @IBOutlet weak var undoImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if firstStudentSignedIn == true && undoCompleted == false && lastSignIn.count > 0 && studentDoesNotExist == false {
        undoImage.image = newStudentData.retrieveImageFor(id:Int(lastSignIn[0].STUDENTNUMBER), forceReload: false)
        nameLabel.text = "\(lastSignIn[0].STUDENTFIRSTNAME) \(lastSignIn[0].STUDENTLASTNAME)"
        }
    }

    
    @IBAction func confirmUndo(_ sender: Any) {
        if firstStudentSignedIn == true && undoCompleted == false && lastSignIn.count > 0 {
            currentStudentArray.append(lastSignIn[0])
            signedInStudents.removeLast()
            lastSignIn.remove(at: 0)
            undoCompleted = true
        }
        else {
        }
        dismiss(animated: true, completion: nil)
    }
}
