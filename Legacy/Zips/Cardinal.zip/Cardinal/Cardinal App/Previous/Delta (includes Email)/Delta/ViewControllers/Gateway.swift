///created by Daniel Kwon '22

import UIKit

class Gateway: UIViewController {

    @IBOutlet weak var endSignIn: UIButton!
    
    @IBOutlet weak var beginSignIn: UIButton!
    
    @IBOutlet weak var advancedSettings: UIButton!
    
    @IBOutlet weak var undoLastStudent: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if checkInStart == false {
        endSignIn.setTitleColor(#colorLiteral(red: 0.937254902, green: 0.9254901961, blue: 0.8980392157, alpha: 0), for: .normal)
        undoLastStudent.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0), for: .normal)
        endSignIn.isHidden = true
        beginSignIn.isHidden = false
        undoLastStudent.isHidden = true
        advancedSettings.isHidden = false
        }
        if checkInStart == true {
        beginSignIn.setTitleColor(#colorLiteral(red: 0.937254902, green: 0.9254901961, blue: 0.8980392157, alpha: 0), for: .normal)
        advancedSettings.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0), for: .normal)
        endSignIn.isHidden = false
        beginSignIn.isHidden = true
        undoLastStudent.isHidden = false
        advancedSettings.isHidden = true
        }
    }
    
    @IBAction func beginButtonPressed(_ sender: Any) {
        checkInStart = true
        beginSignIn.isHidden = true
        endSignIn.isHidden = false
        
        beginSignIn.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0), for: .normal)
        endSignIn.setTitleColor(#colorLiteral(red: 0.6752108932, green: 0.1266627014, blue: 0.1960295141, alpha: 1), for: .normal)
        //sets middle two buttons
        
        advancedSettings.isHidden = true
        undoLastStudent.isHidden = false
        
        advancedSettings.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0), for: .normal)
        undoLastStudent.setTitleColor(#colorLiteral(red: 0.6752108932, green: 0.1266627014, blue: 0.1960295141, alpha: 1), for: .normal)
        //sets bottom two buttons
    }
    
    @IBAction func completeButtonPressed(_ sender: Any) {
        checkInStart = false
        endSignIn.isHidden = true
        beginSignIn.isHidden = false
        
        endSignIn.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0), for: .normal)
        beginSignIn.setTitleColor(#colorLiteral(red: 0.6752108932, green: 0.1266627014, blue: 0.1960295141, alpha: 1), for: .normal)
        //sets middle two buttons
        
        undoLastStudent.isHidden = true
        advancedSettings.isHidden = false
        
        undoLastStudent.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0), for: .normal)
        advancedSettings.setTitleColor(#colorLiteral(red: 0.6752108932, green: 0.1266627014, blue: 0.1960295141, alpha: 1), for: .normal)
        //sets bottom two buttons
    }
}

