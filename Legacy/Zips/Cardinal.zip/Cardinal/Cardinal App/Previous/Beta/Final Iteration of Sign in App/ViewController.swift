//
//  ViewController.swift
//  Final Iteration of Sign in App
//
//  Created by Stewart  Zurbuch on 12/11/19.
//  Copyright © 2019 Stewart  Zurbuch. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var completeCheckIn: UIButton!
    @IBOutlet weak var beginCheckIN: UIButton!
    @IBOutlet weak var advancedSettings: UIButton!
    @IBOutlet weak var undoLastCheckIn: UIButton!
    
    

}

