import UIKit

var lastSignIn: [Student] = []
class ConfirmScreen: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageController.image = newStudentData.retrieveImageFor(id:Int(currentID)!, forceReload: false)
        nameLabel.text = (newStudentData.getStudentBy(id: Int(currentID)!)?.STUDENTFIRSTNAME ?? "") + " " +  (newStudentData.getStudentBy(id: Int(currentID)!)?.STUDENTLASTNAME ?? "Student Does Not Exist!")
    }
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var imageController: UIImageView!
    
    @IBAction func confirmCheckIN(_ sender: Any) {
        for s in newStudentData.students {
            var i = 0
            if Int(s.STUDENTNUMBER) == Int(currentID) {
                if lastSignIn.count == 1 {
                    lastSignIn.remove(at: 0)
                }
                lastSignIn.append(s)
                currentStudentArray.remove(at: i)
            }
            i += 1
        }
        firstStudentSignedIn = true
        undoCompleted = false
        dismiss(animated: true, completion: nil)
    }
}

