import UIKit
import MessageUI
class sendEmail: UIViewController, MFMailComposeViewControllerDelegate  {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    @IBAction func sendData(_ sender: Any) {
        if MFMailComposeViewController.canSendMail() {
            var listOfStudents: String = ""
            for s in newStudentData.students {
                if formArray.contains(s.STUDENTFORM) {
                    if genderArray.contains(s.STUDENTSEX) {
                        listOfStudents += "\(s.STUDENTFIRSTNAME) \(s.STUDENTLASTNAME) \n"
                    }
                }
            }
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients(["\(emailTextField.text!)@standrews-de.org"])
            mail.setMessageBody(listOfStudents, isHTML: true)
            present(mail, animated: true)
            if !errorLabel.isHidden {
                errorLabel.isHidden = true
            }
            
            dismiss(animated: true, completion: nil)
        } else {
            errorLabel.isHidden = false
        }
    }
}
